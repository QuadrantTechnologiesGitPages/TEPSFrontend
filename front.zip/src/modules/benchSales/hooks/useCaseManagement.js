// useCaseManagement hook 
